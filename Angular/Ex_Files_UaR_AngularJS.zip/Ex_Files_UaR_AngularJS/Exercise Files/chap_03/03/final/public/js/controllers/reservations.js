function ReservationsCtrl ($scope) {
	$scope.setActive('reservations');
}