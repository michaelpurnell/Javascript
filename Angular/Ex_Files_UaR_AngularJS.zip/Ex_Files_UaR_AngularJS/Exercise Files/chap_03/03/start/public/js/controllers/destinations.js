function DestinationsCtrl ($scope) {
 	$scope.setActive('destinations');
}