function FlightsCtrl ($scope) {
	$scope.setActive('flights');
}